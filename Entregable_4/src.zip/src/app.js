import express from "express";
import handlebars from "express-handlebars";
import __dirname from "./utils.js";
import { Server } from "socket.io";
import productsRouter from "./routes/products.router.js";
import cartsRouter from "./routes/carts.router.js";

const app = express();
const httpServer = app.listen(8080, () =>
	console.log("Listening on port 8080")
);
const io = new Server(httpServer);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.engine("handlebars", handlebars.engine());
app.set("view engine", "handlebars");
app.set("views", __dirname + "/views");

app.use(express.static(__dirname + "/public"));

app.use("/api/products", productsRouter);
app.use("/api/carts", cartsRouter);

io.on("connection", socket => {
	console.log("A user connected");

	// // Handle events
	socket.on("message", () => {
		// Emit an event to notify clients about a product update
		console.log('Connected');
	});
    socket.emit('message','Tenemos una conexión abierta');

	socket.on("disconnect", () => {
		console.log("A user disconnected");
	});
});
