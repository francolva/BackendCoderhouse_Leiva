console.log('Calling realTimeProducts.js')
const socket = io();