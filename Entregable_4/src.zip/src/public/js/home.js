console.log('Calling home.js')
const socket = io();